
function makeUppercase() {
document.caps.upperCaseString.value = document.caps.lowerCaseString.value.toUpperCase();
}